
public class AuthorisedResidents extends Residents{
	
	AuthorisedResidents(AuthorisedResidents ar, Residents r){
		super(ar, r);
	}
	
	public void olderThanMe(Residents r[], int i){
		if(this.getAuthority() && this.sex.equals("female")){
			int m=0,count=0;
			while (m<i){
				if(r[m].getAge() > this.age)
					count++;
				m++;
			}
			System.out.println("There are " + count + "people older than you");
		}
		else
			System.out.println("You are not allowed to access this data");
	}
	
	public void oldestMale(Residents r[], int i){
		if(this.getAuthority() && this.sex.equals("male")){
			int m=0,maxage=0;
			while(m<i){
				if(r[m].sex.equals("male") && r[m].age > maxage){
					maxage = r[m].age;
				}
				m++;
			}
			System.out.println("The age of the oldest male person is " + maxage);
		}
		else
			System.out.println("You are not allowed to access this data");
	}
	
	public void wantName(String address, Residents r[], int i){
		if(this.age < 18 && this.getAuthority()){
			int m=0;
			while(m<i){
				if(address.equals(r[m].getAddress())){
					System.out.println(r[m].getName());
					break;
				}
				m++;
			}
			if(m==i)
				System.out.println("No one lives here");
		}
		else
			System.out.println("You are not allowed to access this data");
	}
}