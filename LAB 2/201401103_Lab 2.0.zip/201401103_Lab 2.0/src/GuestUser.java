import java.io.*;
import java.util.*;

public class GuestUser {
	public static void main(String[] args) throws FileNotFoundException{
		// TODO Auto-generated method stub
		File f = new File("//home//labex11//Desktop//Lab_2.dat");
		Scanner sc = new Scanner(f);
		Residents[] r = new Residents[50];
		AuthorisedResidents[] ar = new AuthorisedResidents[50];
		int i=0,j=0;
		
		while(sc.hasNextLine()){
			r[i] = new Residents(sc.nextLine(),sc.nextLine(),sc.nextLine(),sc.nextLine(),sc.nextLine());
			if(r[i].getAuthority()){
				ar[j] = new AuthorisedResidents(ar[j], r[i]);
				System.out.println(ar[j].getAuthority());
				j++;
			}
			i++;
		}
		//System.out.println(ar[0].getAuthority());
		ar[0].olderThanMe(r, i);
		ar[1].wantName("C/34, Reed Street", r, i);
		ar[2].oldestMale(r, i);
	}
}
