
public class Residents {
	protected String name,sex,address;
	protected boolean authority=false;
	protected int age;
	
	Residents(String name, String checkAuthority, String sex, String storeAge, String address){
		this.name = name;
		if(checkAuthority.equals("Authority yes"))
			authority = true;
		else
			authority = false;
		this.sex = sex;
		age = Integer.parseInt(storeAge);
		this.address = address;
	}
	
	Residents(Residents ar, Residents r){
		ar = r;
		System.out.println(ar.getAuthority());
	}
	
	public String getName(){
		return name;
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public boolean getAuthority(){
		return authority;
	}
	
	public void setAuthority(boolean authority){
		this.authority = authority;
	}
	
	public String getSex(){
		return sex;
	}
	
	public void setSex(String sex){
		this.sex = sex;
	}
	
	public int getAge(){
		return age;
	}
	
	public void setAge(int age){
		this.age = age;
	}
	
	public String getAddress(){
		return address;
	}
	
	public void setAddress(String address){
		this.address = address;
	}
}