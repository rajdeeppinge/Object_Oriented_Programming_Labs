import java.util.Scanner;
/** main class for stack prog*/
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int maxQueueSize = sc.nextInt();
		MyQueue q1 = new MyQueue(maxQueueSize);
		Object o = null;
		int noOfOperations = sc.nextInt();
		sc.nextLine();
		for(int i=0; i<noOfOperations; i++){
			String[] s1 = sc.nextLine().split(" ");
			if(s1[0].equals("E"))
				q1.enque((Object)s1[1]);
			
			else if(s1[0].equals("D")){
				o = q1.deque();
				System.out.println(o.toString());
			}
	//		q1.printQueue();
		}
		sc.close();
	}

}
