import java.util.Scanner;
/** main class for linked list prog*/
public class Main2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Queue2 qa = new Queue2();
		int inputs = sc.nextInt();
		sc.nextLine();
		for(int i=0; i<inputs; i++){
			String[] s1 = sc.nextLine().split(" ");
			if(s1[0].equals("E"))
				qa.enque((Object)s1[1]);
			
			else if(s1[0].equals("D")){
				Object o = qa.deque();
				if(o!=null)
					System.out.println(o.toString());
			}
		}
		sc.close();
	}
}
