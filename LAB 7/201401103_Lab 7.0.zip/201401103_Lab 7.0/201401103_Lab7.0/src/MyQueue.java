import java.util.Stack;

/** class for stack prog*/
public class MyQueue {
	private Stack st1 = new Stack();
	private Stack st2 = new Stack();
	
	public MyQueue(int minSize){
		st1.ensureCapacity(minSize);
		st2.ensureCapacity(minSize);
	}
	
	public void enque(Object o1){
		st1.push(o1);
	}
	
	public Object deque(){
		if(st1.isEmpty())
			return null;
		while(!st1.isEmpty())	
			st2.push(st1.pop());	//shifting in reverse order
		Object o2 = st2.pop();		//popping last element of st2 which is first element of queue
		while(!st2.isEmpty())
			st1.push(st2.pop());	//shifting back remaining elements
		return o2;
		
	}
	
	public void printQueue(){
		if(st1.isEmpty())
			System.out.println("Queue is Empty");
		else{
			while(!st1.isEmpty())		//shifting elements so that they are in reverse order
				st2.push(st1.pop());
			while(!st2.isEmpty()){		//shifting in right order at the same time printing
				st1.push(st2.pop());
				System.out.println(st1.peek().toString());
			}
		}
	}
}
