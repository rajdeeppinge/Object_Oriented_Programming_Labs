
public class Node {
	public Object nodeObj;
	public Node next;
	
	public Node(Object nodeObj){
		this.nodeObj = nodeObj;
	}
}
