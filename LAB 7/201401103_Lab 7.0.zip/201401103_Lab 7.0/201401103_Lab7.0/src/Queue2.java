/** class for linked list prog*/
public class Queue2 {
	private myLinkedList list1;
	
	public Queue2(){
		list1 = new myLinkedList();
	}
	
	public void enque(Object o1){
		list1.addLast(o1);
	}
	
	public Object deque(){
		Object temp = list1.removeFirst();
		if(temp == null)
			System.out.println("Queue is Empty");
		return temp;
	}
}
