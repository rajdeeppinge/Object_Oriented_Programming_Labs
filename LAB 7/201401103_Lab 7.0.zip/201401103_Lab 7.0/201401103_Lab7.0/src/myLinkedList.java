
public class myLinkedList {
	private Node newNode;
	private Node head = null;
	private Node tail = null;
	
	public void addLast(Object o1){
		newNode = new Node(o1);
		if(head == null)
			head = newNode;
		if(tail == null)
			tail = newNode;
		else{								//shifting tail ahead
			tail.next = newNode;
			tail = newNode;
		}
	}
	
	public Object removeFirst(){
		if(head == null)
			return null;
		Node temp = head;
		head = head.next;				//head shifting ahead
		return temp.nodeObj;
	}
}
